/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author alumno
 */
public class Ingeniero extends Persona{

    private int nroHabilitacion;

    public int getNroHabilitacion() {
        return nroHabilitacion;
    }

    public void setNroHabilitacion(int nroHabilitacion) {
        this.nroHabilitacion = nroHabilitacion;
    }
    
    
    public Ingeniero(String nombre, String tipoDoc, String nroDoc, String sexo, int nroHab) {
        super(nombre, tipoDoc, nroDoc, sexo);
        this.nroHabilitacion = nroHab;
    }


    @Override
    public void presentarse() {
        saludar();
        System.out.println("yo soy Ingeniero");
        System.out.println("me llamo"+ this.getNombre()  );
        System.out.println("Numero de habilitacion" + this.getNroHabilitacion());
        
        
    }
    
}
