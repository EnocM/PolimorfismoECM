/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author alumno
 */
public class Medico extends Persona{
    private int matricula;
    private String especialidad;
    
    public Medico(String nombre, String tipoDoc, String nroDoc, String sexo, int mat, String esp) {
        super(nombre, tipoDoc, nroDoc, sexo);
        this.matricula = mat;
        this.especialidad = esp;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    @Override
    public void presentarse() {
        System.out.println("Yo soy  el " + this.especialidad);
        System.out.println("matricula " + this.matricula);
    }
    
    
    
    
}
