/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

import java.util.ArrayList;
import java.util.Iterator;



/**
 *
 * @author alumno
 */
public class Polimorfismo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         ArrayList<String> pasoscumbia =  new ArrayList<String>();
         pasoscumbia.add("adelante");
         pasoscumbia.add("adelante");
         pasoscumbia.add("adelante");
         pasoscumbia.add("atras");
         pasoscumbia.add("derecha");
         pasoscumbia.add("media vuelta");
         
        Ritmo cumbia = new Ritmo("cumbia", pasoscumbia);
        
        Ritmo rock = new Ritmo("rock",  new ArrayList<String>() {{
                add("adelante"); add("derecha") ; add("adelante");  add("atras");  add("atras");
        }}
        );
        
        Ritmo regeton = new Ritmo ("regeton",pasoscumbia);
        
        Ritmo zamba = new Ritmo ("zamba", new ArrayList<String>());
        
        
        
        
        zamba.setPasos(pasoscumbia);
        
        
        
        
        
        ArrayList<Persona> profesionales = new ArrayList<Persona>();
        Persona p = new Medico("juan","dni", "232342","Masculino",234234,"Pediatra");
        profesionales.add(p);
        Persona i = new Ingeniero ("cristina","dni","343422244","femenino",44444);
        profesionales.add(i);
         p = new Medico("pedro","dni", "232342","Masculino",234234,"Pediatra");
         profesionales.add(p);
         p = new Medico("claudio","dni", "23256565342","Masculino",234234,"Traumatologoa");
         profesionales.add(p);
         p = new Medico("marcelo","dni", "56456523","Masculino",234234,"clinico");
         profesionales.add(p);
         p = new Medico("elisa","dni", "677666","Feenino",234234,"Oculista");
         profesionales.add(p);
         p = new Ingeniero ("daniel","dni","343422244","femenino",44656444);
        profesionales.add(p);
         p = new Ingeniero ("Laura","dni","343422244","femenino",4443344);
        profesionales.add(p);
        
        
        Alumno flor = new Alumno("florencia","dni","222","femenino");
        
        flor.bailar(rock);
       
        profesionales.add(flor);
        
        Iterator it = profesionales.iterator();
        Persona actual;
        while (it.hasNext()){
            actual = (Persona )it.next();
            actual.presentarse();
        }
        
        
        it = profesionales.iterator();
        Alumno alumnoActual;
        Ingeniero ingActual;
        while (it.hasNext()){
            if (it.next() instanceof Alumno){
                alumnoActual = (Alumno)it.next();
                alumnoActual.bailar(cumbia);
            }
            else 
             if (it.next() instanceof Ingeniero){
                ingActual = (Ingeniero) it.next();
                ingActual.bailar(cumbia);
                } 
             else {
                 actual = (Persona )it.next();
                 actual.presentarse();
                 System.out.println("no sabe bailar");
             }
                 
            
        }
    }
    
}