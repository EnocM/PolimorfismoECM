/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author alumno
 */
public class Alumno extends Persona implements IBailarin{

    public Alumno(String nombre, String tipoDoc, String nroDoc, String sexo) {
        super(nombre, tipoDoc, nroDoc, sexo);
    }

    @Override
    public void presentarse() {
        System.out.println("soy un alumno");
    }
    @Override
    public void bailar (Ritmo r){
        ArrayList<String> listaPasos;
        listaPasos =  r.getPasos();
        
       Iterator it = listaPasos.iterator();
        String actual;
        while (it.hasNext()){
            actual = (String) it.next();
            System.out.println(actual);
        }
    }
    
}
